import streamlit as st
import pandas as pd
import plotly.express as px
import numpy as np

st.set_page_config(page_title="RVSA Dashboard", layout="wide")

@st.cache_data
def load_data():
    return pd.read_csv("india_vehicle_sales_cleaned.csv")

df = load_data()

st.title("🚗 RVSA Dashboard")
st.caption("Open this in browser after running streamlit")

st.sidebar.title("Filters")
year = st.sidebar.multiselect("Year", df["Year"].unique(), df["Year"].unique())
state = st.sidebar.multiselect("State", df["State"].unique(), df["State"].unique())

filtered = df[(df["Year"].isin(year)) & (df["State"].isin(state))]

tab1, tab2, tab3 = st.tabs(["Overview", "EV", "Forecast"])

with tab1:
    st.subheader("Regional Sales")
    region_df = filtered.groupby("Region")["Units_Sold"].sum().reset_index()
    fig = px.bar(region_df, x="Region", y="Units_Sold", color="Region")
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    st.subheader("EV Trend")
    ev = filtered[filtered["Fuel_Type"] == "Electric"]
    ev_trend = ev.groupby("Year")["Units_Sold"].sum().reset_index()
    fig2 = px.line(ev_trend, x="Year", y="Units_Sold", markers=True)
    st.plotly_chart(fig2, use_container_width=True)

with tab3:
    st.subheader("Forecast")
    year_map = {"FY2019":1,"FY2020":2,"FY2021":3,"FY2022":4,"FY2023":5,"FY2024":6}
    df["Year_Num"] = df["Year"].map(year_map)
    trend = df.groupby("Year_Num")["Units_Sold"].sum().reset_index()

    x = trend["Year_Num"]
    y = trend["Units_Sold"]

    coeffs = np.polyfit(x, y, 2)
    poly = np.poly1d(coeffs)

    future_x = np.arange(1, 9)
    future_y = poly(future_x)

    fig3 = px.line(x=future_x, y=future_y)
    st.plotly_chart(fig3, use_container_width=True)
